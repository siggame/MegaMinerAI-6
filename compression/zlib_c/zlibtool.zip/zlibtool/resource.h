//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ZlibTool.rc
//
#define IDS_ZLIBTOOL                    1
#define IDD_ABOUTBOX_ZLIBTOOL           1
#define IDB_ZLIBTOOL                    1
#define IDI_ABOUTDLL                    1
#define IDS_ZLIBTOOL_PPG                2
#define IDS_ZLIBTOOL_PPG_CAPTION        100
#define IDD_PROPPAGE_ZLIBTOOL           100
#define IDC_INPUT_FILE                  201
#define IDC_OUTPUT_FILE                 202
#define IDC_COMPRESS_LEVEL              203

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         205
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
